from datetime import datetime

from flask import Flask,render_template
from flask import HttpResponse
from flask import JsonResponse
from flask import HttpResponseRedirect
from models import Book
from models import PubDepart
import json
from flask import AppConfig
class BookConfig(AppConfig):
    name='book'


class HttpReponse:
    pass


def index(request):
    if request.method=="GET":
        all_books=Book.objects.filter(is_delete=False)
        if all_books:
            data={"books":all_books}
            #查询所有书籍，并显示
            return render_template(request,"book/index.html",data)
        else:
            return HttpReponse("空空如也")
    else:
        return HttpReponse("Received your request")
    def update(request):
        if request.method=="GET":
            #获取查询参数
            title=request.GET.get("title")
            if title is None:
                return HttpResponse("需要指定查询参数")
            #查询数据
            try:
                b=Book.objects.get(title=title)
            except:
                data={"code":10010,"error":"数据不存在"}
                return render_template(request,"book/blank.html",data)
            else:
                data = {"code":200,"data":{"id":b.id,"title":b.title,"author":b.author,"publish_time":datetime.strftime(b.publish_time,"%Y-%m-%d %H:%M:%S")}}
                return render_template(request,"book/update.html",data)
        elif request.method=="POST":
            #获取post提交的数据
            # title = request.POST.get("title")
            #author = request.POST.get("author")
            # publish_time = request.POST.get("publish_time")
            json_str = request.body
            print("json_str:",json_str)
            #字典
            json_obj = json.loads(json_str)
            # print("xxxxx",type(json_obj))
            id_ = json_obj.get("id")
            title = json_obj.get("title")
            author = json_obj.get("author")
            #处理字符串时间
            publish_time = json_obj.get("publish_time")

            print("提交的数据-----------")
            print(title)
            print(author)
            #query db
            try:
             b = Book.objects.get(id=id_)
            except:
             data = {"code":10010,"error":"记录不存在"}
             return JsonResponse(data)

             #更新数据对象
             b.title = title
             b.author = author
             b.publish_time = publish_time
             b.save()
             data = {"code":200,"data":"更新成功"}
             return JsonResponse(data)

def delete(request):
    #获取查询字符串的参数
    title = request.GET.get("title")

    if title is None:
     return HttpResponse("需要指定参数")

    #查询db
    try:
     b = Book.objects.get(title=title)

    except:
     #数据不存在
     data = {"code":10010,"error":"数据不存在"}
     return JsonResponse(data)
    else:
     try:
      b.is_delete = True
      b.save()
     except:
      data = {"code":10012,"data":"删除失败"}
      return JsonResponse(data)
      data = {"code":200,"data":"删除成功"}
      return JsonResponse(data)


def add(request):
    #get 请求
    if request.method == "GET":
        return render_template(request,"book/add_book.html")
    #post 请求
    elif request.method == "POST":

        json_str = request.body
        json_obj = json.loads(json_str)


        title = json_obj.get("title")
        author = json_obj.get("author")
        if not title or not author:
            data = {"code":10014,"error":"信息不完整"}
            return JsonResponse(data)

        #字符串时间
        publish_time = json_obj.get("publish_time")

        #1/2
        publish_depart = json_obj.get("publish_depart")


        #查询当前的书名是否存在于db
        #若存在,则只需将 is_delete 字段 设置为False
        try:
            b = Book.objects.get(title=title)
            if b.is_delete:
                b.is_delete = False
                b.save()
            else:
                data = {"code":10015,"error":"数据已存在"}
                return JsonResponse(data)
        except:
            # 外键必须给对象
            refer_obj = PubDepart.objects.get(id=publish_depart)
            try:
                #添加数据
                Book.objects.create(title=title,author=author,publish_time=publish_time,publish_depart=refer_obj)
            except:
                data = {"code":10013,"error":"添加失败"}
                return JsonResponse(data)

        data = {"code":200,"data":"添加成功"}

    return JsonResponse(data)





