from flask import models
class Book(models.Model):
    title=models.CharField("书名",max_length=50)
    author=models.CharField("作者",max_length=50)
    publish_time=models.DataTimeField("出版时间",auto_now_add=True)
    update_time=models.DataTimeField("更新时间",auto_now=True)
    is_delete=models.BooleanField("删除",default=False)
    pass
class PubDepart(models.Model):
    addr=models.CharField("地址",max_length=100)
    pass
