"""
热门搜索词：
本质上来说就是直接从查询关键词表中的is_hot=true的前多个值
判断是否热门的部分在搜索高精准匹配中实现，用count记录所有搜索的关键词，如果>10，标记is_hot=true
搜索关键词：
获取关键词对书籍数据库进行过滤查询
精准&高匹配&推荐：
获取关键词查询SearchKeyWord表，如果这个词里面没有，就创建一个，有的话计数器加一，用来标记热门词
精准匹配要求书名相同。模糊匹配只要包含该词就可以，推荐就是和前面查询结果不一样的书中选出几条
这里的推荐词条数可以按具体设计页面作调整
推荐算法比较简单，如果要扩展，需要人工智能相关
"""
"""
推荐算法：usercf
(1)将用户收藏的书作为用户特征，计算用户相似度矩阵
（2）根据矩阵得到与用户相似的k个用户，将相似度作为权值累加，从相似用户收藏的书中排名前n的物品推荐给用户



"""



from models import SearchKeyWord, Book, db

#导入蓝图
from flask import Blueprint, request, jsonify, current_app

#导入sqlaclchemy提供的逻辑运算符(高匹配和推荐都要求结果前面没有出现)
from sqlalchemy import not_

from usercf import *
from collections import defaultdict

#创建蓝图对象
search_bp = Blueprint('search', __name__, '/search')

#定义路由，关键词热门搜索
@search_bp.route("/tags")
def tag_list():
    # 1,获取参数，用户搜索的关键词key_word
    key_word = request.args.get("key_word")
    #校验参数
    if not key_word:
        return jsonify([])
    # 2,根据参数，查询数据库，在搜索关键词表进行过滤查询，过滤关键词
    # 热门关键词默认提供10条数据
    search_list = SearchKeyWord.query.filter(SearchKeyWord.keyword.contains(key_word)).limit(10)
    # 3，返回查询结果
    data = [{
        'title':index.keyword,
        'isHot':index.is_hot,
    }for index in search_list]
    #转成json返回
    return jsonify(data)

#定义路由，搜索关键词列表
@search_bp.route('/books')
def search_books():
    # 1,获取参数，key_word/page/pagesize
    key_word = request.args.get("key_word")
    page = request.args.get('page', 1, int)
    pagesize = request.args.get('pagesize', 10, int)
    # 2,检查关键词参数是否存在
    if not key_word:
        return jsonify(msg='参数错误'),400
    # 3,根据关键词参数，对书籍数据库进行过滤查询，包含
    query = Book.query.filter(Book.book_name.contains(key_word))
    # 4,判断查询结果（不判断为空时可以直接返回空值）
    # 5,对查询结果进行分页处理,items/page(当前页面)/pages
    query.paginate(page, pagesize, False)#false的情况分页异常不报错
    # 获取分页后的书本数据
    book_list = paginate.items
    # 6，遍历分页后的数据，获取每本书的数据
    items = []
    for book in book_list:
        items.append({
            'id':book.book_id,
            'title':book.book_name,
            'intro':book.intro,
            'author':book.author_name,
            'state':book.status,
            'category_id':book.cate_id,#类别id
            'category_name':book.cate_name,
            #'imgURL':'http://{}/{}'.format(current_app.config.get(['QINIU_SETTINGS']['host']).book_cover)
            #封面
        })
    # 7,返回结果
    data = {
        'count':paginate.total,
        'pages':paginate.pages,
        'page':paginate.page,
        'items':items
    }
    return jsonify(data)



#定义路由：搜索，精准匹配，高匹配，推荐
@search_bp.route('recommends')
def recommends():
    # 1，获取参数搜索关键词
    key_word = request.args.get("key_word")
    # 2，根据关键词搜索SearchKeyWord表
    skw = SearchKeyWord.query.filter(SearchKeyWord.keyword==key_word).first()
    # 3,判断查询结果，关键词是否存在
    # 4,如果不存在，保存该关键词
    if skw is None:
        skw = SearchKeyWord(keyword=key_word,count=0)
    # 5,关键词存在，count+1，count>10，标记为热门
    skw.count += 1
    if skw.count >= 10:
        skw.is_hot=True
    db.session.add(skw)
    db.session.commit()
    # 6，定义容器列表，用来存储7条书籍数据，进行数据重复判断
    book_list = []
    # 7,精准匹配一条，根据关键词查询书籍表，用书籍名称进行匹配，保存数据
    accurate_data = Book.query.filter_by(book_name=key_word).first()
    # 定义精准匹配到的字典容器，用来存储匹到的书籍数据
    accurate = {}
    # 如果有数据
    if accurate_data:
        accurate = {
            'id':accurate_data.book_id,
            'titile':accurate_data.book_name,
            'intro':accurate_data.intro,
            'state':accurate_data.status,
            'category_id':accurate_data.cate_id,
            'category_name':accurate_data.cate_name,
           # 'imgURL':'http://{}/{}'.format(current_app.config.get(['QINIU_SETTINGS']['host']),accurate_data.book_cover)
            #封面 QINIU_SETTINGS视服务器而定
        }
        book_list.append(accurate_data.book_id)
    # 8,高匹配两条，根据书名包含查询关键词，并且，该书不是精确查询到的数据，默认提取两条，保存数据
    query = Book.query.filter(Book.book_name.contains(key_word)).not_(Book.book_id.in_(book_list))
    match_data = query.limit(2)
    match = []
    for book in match_data:#两条数据遍历放进match中
        match.append({'id':book.book_id,
            'titile':book.book_name,
            'intro':book.intro,
            'state':book.status,
            'category_id':book.cate_id,
            'category_name':book.cate_name,
           # 'imgURL':'http://{}/{}'.format(current_app.config.get(['QINIU_SETTINGS']['host']),book.book_cover)
                      })
        book_list.append(book.book_id)
    # 9，推荐4条：根据usercf算法查询书架，找出收藏相似的用户看过的书；对于收藏太少的用户，返回收藏数最多的几本书
    # 如果想返回热门书籍，仅凭热门关键词，可能出现书籍和关键词重复的问题，无法判断到底真正热门的是这个关键词对应的哪几本书
    user = g.user_id

    fav_book = bookshelf.query.filter(bookshelf.user_id==user).all()
    #如果该用户没有收藏书籍，查找书架中被收藏次数最多的4本书
    if len(fav_book)<1:
        # keyword = SearchKeyWord.query.order_by(count).limit(10)

        bs = bookshelf.query.all()
        num = {}
        for b in bs:
            if b.book_id not in num:
                num[b.book_id] = 0
            num[b.book_id] += 1
        recom_data= sorted(num.items(),key=itemgetter(1),reverse=True)[0:4]
    # 否则用UserBasedCf类的方法得到相似用户的推荐
    else:
        recom = UserBasedCf()
        recom.get_dataset()
        recom.calc_user_sim()
        recom_data = recom.recommend(user)

    # 根据以上方法提供的书籍id遍历Book表，返回对应书籍数据
    recommend = []

    for book_id in recom_data.keys():
        book_data = Book.query.filter_by(book_id=book.book_id).all()
        recommend.append({'id':book_data.book_id,
            'titile':book_data.book_name,
            'intro':book_data.intro,
            'state':book_data.status,
            'category_id':book_data.cate_id,
            'category_name':book_data.cate_name,
            # 'imgURL':'http://{}/{}'.format(current_app.config.get(['QINIU_SETTINGS']['host']),book_data.book_cover)
                      })


    # 10，返回结果，精确匹配1条，高匹配2条，推荐4条，共7条数据
    data={
        'accurate':accurate,
        'match':match,
        'recommends':recommend
    }
    return jsonify(data)