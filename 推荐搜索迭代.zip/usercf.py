import math
from operator import itemgetter
from models import db, bookshelf
from flask import Flask
from flask_sqlalchemy import SQLAlchemy


class UserBasedCf(db.Model):
    # 初始化
    def __init__(self, users=10, rec=4):
        # 最相似的10个用户
        self.n_sim_user = users
        # 推荐4本书
        self.n_rec_rbook = rec
        # 将数据集划分为训练集和测试集，这里只划了训练集，如果要划测试集数据要多一点

        self.trainSet = {}
        # 用户相似度矩阵
        self.user_sim_matrix = {}
        self.rbook_count = 0

    # 读取书架数据，建立用户-书籍字典
    def get_dataset(self):
        data={}
        r_b_data = bookshelf.query.all()
        for book in r_b_data:
            if book.user_id not in data:
                data[user_id] = set()
            data[user_id].add(book.book_id)
            # my_tmp_dict={"book":book.book_id,"user":book.user_id}
            # data.update(**my_tmp_dict)
        self.trainSet = data.copy()

    def calc_user_sim(self):
        # 构建“书籍-用户”倒排索引，一本书对应所有收藏它的用户
        rbook_user = {}

        for user, rbook in self.trainSet.items():
            #for rbook in rbooks:
            if rbook not in rbook_user:
                 rbook_user[rbook] = set()
            rbook_user[rbook].add(user)

        # 计算书籍的数目
        self.rbook_count = len(rbook_user)

        # 初始化用户之间的相似度矩阵：收藏同一本书的两个用户权重加一，之后计算相似度的时候可以忽略权重为0的用户
        for rbook, users in rbook_user.items():
            for u in users:
                for v in users:
                    if u == v:
                        continue
                    self.user_sim_matrix.setdefault(u, {})
                    self.user_sim_matrix[u].setdefault(v, 0)
                    weight = 1
                    # 根据热门程度加权
                    # weight = 1/math.log2(1+len(users))
                    self.user_sim_matrix[u][v] += weight

        # 计算用户之间的相似度
        for u, related_users in self.user_sim_matrix.items():
            for v, count in related_users.items():
                # 余弦相似度公式
                self.user_sim_matrix[u][v] = count / math.sqrt(len(self.trainSet[u]) * len(self.trainSet[v]))
                # Jaccard公式
                # self.user_sim_matrix[u][v] = count / (len(self.trainSet[u]) + len(self.trainSet[v])-count)

    def recommend(self, user):
        # 和用户相似的前K个用户
        K = self.n_sim_user
        # 推荐书的数目
        N = self.n_rec_rbook
        rank = {}
        watched_rbooks = self.trainSet[user]#所查询用户收藏的书

        # v是相似用户, wuv是对应相似用户的相似权重，如果两个用户收藏书籍相似度很高，那么这个用户收藏的书籍加权更高
        for v, wuv in sorted(self.user_sim_matrix[user].items(), key=itemgetter(1), reverse=True)[0:K]:
            for rbook in self.trainSet[v]:
                # 用户已经收藏的书直接略过——是否改成用户已经看过的书略过
                if rbook in watched_cookbooks:
                    continue
                rank.setdefault(rbook, 0)
                # 统计K个人里有多少观看权重
                rank[rbook] += wuv

        return sorted(rank.items(), key=itemgetter(1), reverse=True)[0:N]

    #保存到数据库——是否需要？还是直接计算返回，考虑到收藏数据在不断变化，推荐用户也可能变化
    #如果要保存，需要新建一个table
"""
    def save(self):
        db.create_all()
        rec_list = []
        # 存储用户-产品推荐表(UCF)
        for user, rbooks in self.trainSet.items():
            for (cid, score) in self.recommend(user):
                rec_list.append(UCFRec(uid=user, cid=cid, score=score))
        db.session.add_all(rec_list)
        db.session.commit()
"""






