"""
对应小说阅读部分功能实现


有问题的地方：
manage.py路由映射关系如何搭建
如何搭建对应数据库，调用数据库对应信息


需要的数据库：
@mybooks_bp:user_id
User:靠user_id查询对应用户信息 ，
BookChapters:chapter_id

ReadRate:user_id,book_id,，last_read_chapter_id


输出：
若用户没有阅读，即not user.last_read,查询Book存储第一本书，返回user_id,book_id,chapter_id,chapter_name
若用户有阅读，查询用户id对应的ReadRate，返回值里面多了阅读进度和书的封面
"""



from flask import Blueprint
mybooks_bp = Blueprint('mybooks', __name__, url_prefix='/mybooks')

# 导入flask库（jsonify函数）
from flask import Flask,jsonify

# 导入模型类书架
from models import Book,db,User,BookChapters,ReadRate



# 定义路由，书架管理——最后阅读
@login_required
@mybooks_bp.route("/last")
def book_last_reading():
    # - 1，使用登录验证装饰器，获取用户信息
    user_id = g.user_id
    user = User.query.get(user_id)
    read_rate = None
    # - 2，判断用户没有阅读书籍
    if not user.last_read:
        # - 3，如果用户没有阅读，默认查询第一本书籍，当作用户的阅读书籍——也可以查询书架第一本书
        book = Book.query.first()
        # - 保存用户的阅读书籍的id
        user.last_read = book.book_id
        # - 4，查询该书籍的章节信息，默认升序排序
        bk_chapter = BookChapters.query.filter_by(book_id=book.book_id).order_by(BookChapters.chapter_id.asc()).first()
        # 保存用户的阅读书籍的章节信息
        user.last_read_chapter_id = bk_chapter.chapter_id
        #    -把查询结果，存入阅读进度器
        read_rate = ReadRate(
            user_id=user.id,
            book_id=book.book_id,
            chapter_id=bk_chapter.chapter_id,
            chapter_name=bk_chapter.chapter_name
        )
        # 保存两个对象，参数必须列表
        db.session.add_all([read_rate,user])
        db.sessiom.commit()
    # - 5，如果用户有阅读书籍，查询用户阅读的书籍
    else:
        book = Book.query.get(user.last_read)
    # - 6，判断是否有阅读进度，查询阅读进度表
    if not read_rate:
        read_rate = ReadRate.query.filter_by(
            user_id=user.id,
            book_id=book.book_id,
            chapter_id= last_read_chapter_id
        ).first()
    # - 7，返回查询结果
    data = {
        'id':book.book_id,
        'title':book.book_name,
        'chapter':read_rate.chapter_name,
        'progress':read_rate.rate,
        'imgURL':'http://{}/{}'.format(current_app.config['QINIU_SETTINGS']['host'],book.cover)
    # 上面那个是返回封面的
    }
    #转成json格式返回数据
    return jsonify(data)
    pass