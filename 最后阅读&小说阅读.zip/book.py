# 导入蓝图
from flask import Blueprint, request, jsonify

# 导入模型类
from models import Book, BookChapters, BookChapterContent, ReadRate


"""
对应最后阅读功能实现



以下是最后阅读功能使用到的类相关成员
class Book(db.Model):
    __tablename__ = 'book'  # 表名
    book_id = db.Column(db.Integer, primary_key=True)  # id字段, int 类型,主键
    book_name = db.Column(db.String(64))  # name字段, 字符串类型,唯一

class BookChapters(db.Model):
    __tablename__='book_chapters'
#    id=db.Column(db.Integer,primary_key=True)    #章表id 主码
    #这里查询的是chapter_id，但是模型中没有，注意测试加上去#
    chapter_id=db.Column(db.Integer,primary_key=True)
    book_id=db.Column(db.Integer, db.ForeignKey('book.book_id'))   #书id 外码


class ReadRate(db.Model):
    # 阅读进度
    _tablename_ = 'read_rate'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    book_id = db.Column(db.Integer)
    chapter_id = db.Column(db.Integer)
    chapter_name = db.Column(db.String(100))
    
    
    用户相关：
    class User(UserMixin, db.Model) :
    _tablename_ = 'user'
    user_id = db.Column(db.String(128),unique=True)
    last_read = db.Column(db.Integer())
    last_read_chapter_id = db.Column(db.Integer())

"""




"""
最后阅读功能：
Book : 靠book_id查询对应书籍 , 
BookChapters : 靠chapter_id查询对应章节信息
BookChapterContent:


chapter_id靠读取request中的args参数来获得数据


"""

# 创建阑入对象
book_bp = Blueprint('book', _name_, url_prefix='/book')

# 定义路由，小说阅读
@book_bp.route("/reader/<int:book_id>")
def reader(book_id):
    # 1,根据书籍id,查询书籍表，确认书籍的存在
    book = Book.query.get(book_id)
    if not Book:
        return jsonify(msg='书籍不存在'), 404
    # 2，获取查询字符串参数章节id,校验参数
    chapter_id = request.args.get('chapter_id', -1, int)
    if chapter_id < 1:
        return jsonify(msg='章节id不能小于1'), 400
    # 3，根据章节id，查询书籍章节表
    chapter = BookChapters.query.get(chapter_id)
    # 4,判断查询结果
    if not chapter:
        return jsonify(msg='章节不存在'), 404
    # 5，如果数据存在，查询书籍内容表
    content = BookChapterContent.query.filter_by(book_id=book_id, chapter_id=chapter_id).first()
    # 6，如果用户登录，查询用户阅读进度表
    progress = None
    if g.user_id:
        progress = ReadRate.query.filter_by(book_id=book_id, chapter_id=chapter_id, user_id=g.user_id)
    #构造相应数据
    data =  {
        'id':book_id,
        'title':book.book_name,
        'chapter_id':chapter.chapter_id,
        'chapter_name':chapter.chapter_name,
        'progress':progress.rate if progress else 0,#避免progress不存在的情况，如果为空，不会调用rate
        'article_content':content.content if content else ''
    }
    # 7,返回
    return jsonify(data)
